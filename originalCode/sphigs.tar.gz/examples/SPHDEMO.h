#include "sphigslocal.h"
#include <stdio.h>
#include <stdlib.h>

#define firebrick	 7

#define red		10
#define grey		11
#define orange		12
#define yellow		13
#define limegreen	14
#define forestgreen	15
#define blue		16

/*
#define PI  3.141592653589
*/
