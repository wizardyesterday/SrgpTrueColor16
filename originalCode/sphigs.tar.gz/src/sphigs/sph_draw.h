/* A LIST OF THE DRAWING PROCEDURES THAT THE TRAVERSER NEEDS TO CALL.
 * Each Draw procedure returns the PDC extent of the image, pre-clipping.
 * (Remember: SRGP does the clipping.)
 */

/* CURRENTLY, NO DRAW ROUTINES RETURN PDC EXTENTS! */
